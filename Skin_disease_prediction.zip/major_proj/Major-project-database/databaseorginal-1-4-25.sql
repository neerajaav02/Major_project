/*
SQLyog Community v13.1.6 (64 bit)
MySQL - 10.4.32-MariaDB : Database - skin_disease
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`skin_disease` /*!40100 DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci */;

USE `skin_disease`;

/*Table structure for table `appointment` */

DROP TABLE IF EXISTS `appointment`;

CREATE TABLE `appointment` (
  `appointment_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `doctor_id` int(11) DEFAULT NULL,
  `appoin_date` varchar(100) DEFAULT NULL,
  `appoin_status` varchar(100) DEFAULT NULL,
  `amount` varchar(100) DEFAULT '500',
  PRIMARY KEY (`appointment_id`)
) ENGINE=MyISAM AUTO_INCREMENT=28 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

/*Data for the table `appointment` */

insert  into `appointment`(`appointment_id`,`user_id`,`doctor_id`,`appoin_date`,`appoin_status`,`amount`) values 
(1,3,3,'','Appointment Fixed','500'),
(2,2,2,'','Appointment Fixed','500'),
(12,6,1,'2024-10-28T16:46','Appointment Fixed','500'),
(13,NULL,5,'2025-03-04','pending','500'),
(14,5,5,'2025-03-30','pending','500'),
(22,8,0,'2025-04-01','pending','500'),
(21,8,0,'2025-04-01','pending','500'),
(20,8,0,'2025-04-01','pending','500'),
(19,5,0,'2025-04-01','pending','500'),
(23,8,0,'2025-04-01','pending','500'),
(24,8,0,'2025-04-01','pending','500'),
(25,8,0,'2025-04-01','pending','500'),
(26,8,5,'2025-04-01','pending','500'),
(27,8,7,'2025-04-01','pending','500');

/*Table structure for table `auth_group` */

DROP TABLE IF EXISTS `auth_group`;

CREATE TABLE `auth_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

/*Data for the table `auth_group` */

/*Table structure for table `auth_group_permissions` */

DROP TABLE IF EXISTS `auth_group_permissions`;

CREATE TABLE `auth_group_permissions` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_group_permissions_group_id_permission_id_0cd325b0_uniq` (`group_id`,`permission_id`),
  KEY `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` (`permission_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

/*Data for the table `auth_group_permissions` */

/*Table structure for table `auth_user_groups` */

DROP TABLE IF EXISTS `auth_user_groups`;

CREATE TABLE `auth_user_groups` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_user_groups_user_id_group_id_94350c0c_uniq` (`user_id`,`group_id`),
  KEY `auth_user_groups_group_id_97559544_fk_auth_group_id` (`group_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

/*Data for the table `auth_user_groups` */

/*Table structure for table `auth_user_user_permissions` */

DROP TABLE IF EXISTS `auth_user_user_permissions`;

CREATE TABLE `auth_user_user_permissions` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_user_user_permissions_user_id_permission_id_14a6b632_uniq` (`user_id`,`permission_id`),
  KEY `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` (`permission_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

/*Data for the table `auth_user_user_permissions` */

/*Table structure for table `django_admin_log` */

DROP TABLE IF EXISTS `django_admin_log`;

CREATE TABLE `django_admin_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `action_time` datetime(6) NOT NULL,
  `object_id` longtext DEFAULT NULL,
  `object_repr` varchar(200) NOT NULL,
  `action_flag` smallint(5) unsigned NOT NULL,
  `change_message` longtext NOT NULL,
  `content_type_id` int(11) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `django_admin_log_content_type_id_c4bce8eb_fk_django_co` (`content_type_id`),
  KEY `django_admin_log_user_id_c564eba6_fk_auth_user_id` (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

/*Data for the table `django_admin_log` */

/*Table structure for table `django_session` */

DROP TABLE IF EXISTS `django_session`;

CREATE TABLE `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime(6) NOT NULL,
  PRIMARY KEY (`session_key`),
  KEY `django_session_expire_date_a5c62663` (`expire_date`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

/*Data for the table `django_session` */

insert  into `django_session`(`session_key`,`session_data`,`expire_date`) values 
('76j9vpj7lc1sbg0efv65ppydlymp00ob','eyJsaWQiOjExLCJiaWQiOjQsIm5pZCI6MiwiY19pZCI6MSwiVUlEIjozfQ:1qmov8:QY4R2EZTIw0RJW9WfM1wQeMxoq57bujCnH_CgPLHPB0','2023-10-15 05:23:10.550262'),
('clxt7ivhh3d0ycf622xm1jgkmfd58j21','eyJiaWQiOjUsIm5pZCI6MiwiY19pZCI6MSwibGlkIjo1fQ:1qpirR:vQfD7GP_nPjc44w76pUr5YGxHRVwT91nPR5hQX-UqnI','2023-10-23 05:31:21.201763'),
('hp458w1chbq4xqmq8felky5i5y0dwk4x','.eJxVjsEOwiAQRP-FsyHAFiwevfcbCOwuUm3apLQn479bkh70Om_mZd4ixH0rYa-8hpHETWhx-c1SxBfPDdAzzo9F4jJv65hkq8iTVjksxNP97P4JSqzlWEcHGciljKAheWs77Thz5xUaUkn3JibOqK5OU7bKIxjsvOvpQNYbPqRT-2fg8wXyFzpI:1r0FHI:-6xz6DEL0LCzDr5oXa2eZkDRXxzMOeyl52hGp4IMd2I','2023-11-21 06:09:32.974489'),
('ib88gj864m4duuth7xczxelpj1h15rrt','.eJxVjkEOwiAQRe_C2hAGBnBcuvcMzQCjrTYlKe3KeHet6UK3_728_KfqeF36bm0yd0NRJwXq8Lslzg-ZNlDuPN2qznVa5iHpTdE7bfpSi4zn3f0L9Nz6LUtCvhQ0ZEKkmI9OgnjwDsAbxIgBLBhHOVICiYCePUa2IsLXZMMnOn7_WVKvNweMORo:1r6ZVS:_zPQFNFtnWGkCRRGSzxYlBc1sEHUbeRcMDk2SwFKWKw','2023-12-08 16:58:18.390869'),
('jkzf500vv4w19lydyqzshiat9deb9sp8','.eJxVjsEOwiAQRP-FsyHAFiwevfcbCOwuUm3apLQn479bkh70Om_mZd4ixH0rYa-8hpHETWhx-c1SxBfPDdAzzo9F4jJv65hkq8iTVjksxNP97P4JSqzlWEcHGciljKAheWs77Thz5xUaUkn3JibOqK5OU7bKIxjsvOvpQNYbPqRT-2fg8wXyFzpI:1r0GAr:1f3G1tyateGozeDBX4dTrr-VbCj3GTT2LSHsVbI8yTc','2023-11-21 07:06:57.913223'),
('nwr3gnrob35e5jzxb6fk7516rakol9ch','.eJxVjDsOwyAQBe9CHSE-hpiU6X0GBLtLcGKBZOwqyt1jJDduZ-a9L1tmZA9zYz7sW_Z7o9V3wiS7sBjgQ6ULfIfyqhxq2dY58p7w0zY-VaTlebaXgxxaPtbB6qTRxgRa6uiMGaSlRIMToFBEOaoQKYG4W4nJCAdaweDsiIcyThH7_QFidzoY:1qu3YX:Kxey9B2G-SVqm2itCThRLrZ8uFVVE11W5YK7lLr3Z50','2023-11-04 04:25:45.546291'),
('r94jpt5aiq9vnj8jxf1giv0vq7rl7cla','e30:1r0Ejh:-cPNvMSbe2M5clQIYtWl_oKiOB5C-woAls9QxQcQ0kI','2023-11-21 05:34:49.471631');

/*Table structure for table `doctor` */

DROP TABLE IF EXISTS `doctor`;

CREATE TABLE `doctor` (
  `doctor_id` int(11) NOT NULL AUTO_INCREMENT,
  `login_id` int(11) DEFAULT NULL,
  `fname` varchar(100) DEFAULT NULL,
  `lname` varchar(100) DEFAULT NULL,
  `place` varchar(100) DEFAULT NULL,
  `phone` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`doctor_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

/*Data for the table `doctor` */

insert  into `doctor`(`doctor_id`,`login_id`,`fname`,`lname`,`place`,`phone`,`email`) values 
(5,19,'Chippymol','kb','ernakulam','9876545678','kkkkk@gmail.com'),
(7,31,'minu','minu','peruva','6543298760','minu@gmail.com'),
(8,32,'renuka','rani','kochi','8765432109','renuka@gmail.com');

/*Table structure for table `dos_app_blacklist` */

DROP TABLE IF EXISTS `dos_app_blacklist`;

CREATE TABLE `dos_app_blacklist` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ip` varchar(800) NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

/*Data for the table `dos_app_blacklist` */

/*Table structure for table `dos_app_branch` */

DROP TABLE IF EXISTS `dos_app_branch`;

CREATE TABLE `dos_app_branch` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `branchname` varchar(100) NOT NULL,
  `place` varchar(100) NOT NULL,
  `post` varchar(100) NOT NULL,
  `pin` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(100) NOT NULL,
  `LOGIN_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `dos_app_branch_LOGIN_id_592d0f6d_fk_dos_app_login_id` (`LOGIN_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

/*Data for the table `dos_app_branch` */

/*Table structure for table `enquiry` */

DROP TABLE IF EXISTS `enquiry`;

CREATE TABLE `enquiry` (
  `equiry_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `enquiry` varchar(100) DEFAULT NULL,
  `enq_date` varchar(100) DEFAULT NULL,
  `enq_reply` varchar(100) DEFAULT NULL,
  `doctor_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`equiry_id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

/*Data for the table `enquiry` */

insert  into `enquiry`(`equiry_id`,`user_id`,`enquiry`,`enq_date`,`enq_reply`,`doctor_id`) values 
(1,1,'hi','2024-10-15','dfgh',NULL),
(2,1,'iuygf','2024-10-15','pending',NULL),
(3,1,'fghj','2024-10-15','pending',NULL),
(4,1,'fghj','2024-10-15','pending',NULL),
(5,1,'fgyuiyuthnf','2024-10-15','pending',NULL),
(6,1,'dtydy','2024-10-15','pending',NULL),
(7,12,'hi','2024-11-19','pending',NULL),
(8,12,'hi','2024-11-19','pending',NULL),
(9,12,'hi','2024-11-19','pending',NULL),
(10,12,'hi','2024-11-19','pending',NULL),
(11,12,'hi','2024-11-19','pending',NULL),
(12,12,'vjcj','2024-11-19','pending',NULL),
(13,12,'vjcj','2024-11-19','pending',NULL),
(14,12,'fjdf','2024-11-19','pending',NULL),
(15,12,'fv','2024-11-19','pending',NULL),
(16,16,'i have one doubt ','2025-04-01','ok i will clear it',7),
(17,16,'i have one doubt ','2025-04-01','haii',7),
(18,23,'hello how are u','2025-04-01','fine',5),
(19,23,'irritation','2025-04-01','ok',7);

/*Table structure for table `login` */

DROP TABLE IF EXISTS `login`;

CREATE TABLE `login` (
  `login_id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(111) DEFAULT NULL,
  `password` varchar(111) DEFAULT NULL,
  `usertype` varchar(111) DEFAULT NULL,
  PRIMARY KEY (`login_id`)
) ENGINE=MyISAM AUTO_INCREMENT=34 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

/*Data for the table `login` */

insert  into `login`(`login_id`,`username`,`password`,`usertype`) values 
(1,'admin','admin','admin'),
(3,'doc1','doc1','doctor'),
(4,'doc1','doc1','doctor'),
(6,'doc4','doc4','doctor'),
(7,'doc5','doc5','doctor'),
(8,'doc6','doc6','doctor'),
(9,'doc7','doc7','doctor'),
(10,'hai','hai','user'),
(27,'raj','raj','doctor'),
(17,'arya','arya','user'),
(16,'ammu','ammu','user'),
(19,'chippy','chippy','doctor'),
(20,'uuuu','uuuu','user'),
(21,'meera','meera','doctor'),
(22,'hi','hi','user'),
(23,'roy','roy','user'),
(24,'meera','meera','doctor'),
(25,'meera','meera','doctor'),
(26,'renu','renu','doctor'),
(28,'riya','riya','doctor'),
(32,'renuka','renuka','doctor'),
(30,'tina','tina','doctor'),
(31,'minu','minu','doctor'),
(33,'sara','sara','user');

/*Table structure for table `payment` */

DROP TABLE IF EXISTS `payment`;

CREATE TABLE `payment` (
  `payment_id` int(11) NOT NULL AUTO_INCREMENT,
  `appointment_id` int(11) DEFAULT NULL,
  `booking_amount` varchar(100) DEFAULT NULL,
  `booking_date` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`payment_id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

/*Data for the table `payment` */

insert  into `payment`(`payment_id`,`appointment_id`,`booking_amount`,`booking_date`) values 
(1,2,'700','02-11-2025'),
(2,20,'500','2025-03-04'),
(3,20,'500','2025-03-04'),
(4,20,'500','2025-03-04'),
(5,20,'500','2025-03-04'),
(6,20,'500','2025-03-04'),
(7,20,'500','2025-03-04'),
(8,20,'500','2025-03-04'),
(9,13,'500','2025-03-04'),
(10,14,'500','2025-03-30'),
(15,19,'500','2025-04-01'),
(16,20,'500','2025-04-01'),
(17,21,'500','2025-04-01'),
(18,22,'500','2025-04-01'),
(19,23,'500','2025-04-01'),
(20,24,'500','2025-04-01'),
(21,25,'500','2025-04-01'),
(22,26,'500','2025-04-01'),
(23,27,'500','2025-04-01');

/*Table structure for table `prediction` */

DROP TABLE IF EXISTS `prediction`;

CREATE TABLE `prediction` (
  `prediction_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `datasuploaded` varchar(111) DEFAULT NULL,
  `output` varchar(111) DEFAULT NULL,
  `datetime` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`prediction_id`)
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

/*Data for the table `prediction` */

insert  into `prediction`(`prediction_id`,`user_id`,`datasuploaded`,`output`,`datetime`) values 
(1,6,'static/uploads/67e71a33-2b58-4f70-a477-a201c7860d101000159131.jpg','Bullous Disease Photos','2025-01-17'),
(3,NULL,'static/uploads/1c810ed8-8741-47c3-a75b-171e8293e645abc.jpg','Result :  Melanoma Skin Cancer Nevi and Moles  \nCancer Result :  Melanoma','2025-03-04'),
(4,NULL,'static/uploads/e4778335-15a4-48b1-9b3a-5000c532afa4abc.jpg','Result :  Melanoma Skin Cancer Nevi and Moles  \nCancer Result :  Melanoma','2025-03-04'),
(5,NULL,'static/uploads/839a021c-e367-45fa-b6c0-9f71b11b782babc.jpg','Result :  Melanoma Skin Cancer Nevi and Moles  \nCancer Result :  Melanoma','2025-03-04'),
(6,NULL,'static/uploads/4f8df9cb-a555-4872-9e16-a053ca9cf698abc.jpg','Result :  Melanoma Skin Cancer Nevi and Moles  \nCancer Result :  Melanoma','2025-03-04'),
(7,5,'static/uploads/fbd1d514-c14c-4283-873f-032a6cee1fcbabc.jpg','Result :  Melanoma Skin Cancer Nevi and Moles  \nCancer Result :  Melanoma','2025-03-04'),
(8,5,'static/uploads/a1423f9c-0268-497f-9a9c-41251ba4f2efabc.jpg','Result :  Eczema Photos  \n No Cancer ','2025-03-04'),
(9,5,'static/uploads/fb68dc6b-09b0-426c-93a4-a71bd28d06a8abc.jpg','Result :  Scabies Lyme Disease and other Infestations and Bites  \n No Cancer ','2025-03-04'),
(10,5,'static/uploads/8d372519-03c0-4a7c-b697-f1ea60b9956cabc.jpg','Result :  Bullous Disease Photos  \n No Cancer ','2025-03-30'),
(11,5,'static/uploads/ac128bf0-4006-409b-88b9-24cd0e07d71dabc.jpg','Result :  Invalid Image  \n No Cancer ','2025-03-31'),
(12,5,'static/uploads/25d66c48-d0c9-45f9-b291-595afd6d36f2abc.jpg','Result :  Bullous Disease Photos  \n No Cancer ','2025-03-31'),
(13,5,'static/uploads/837747cd-3cd3-433a-8a63-e69f0224582fabc.jpg','Result :  Melanoma Skin Cancer Nevi and Moles  \nCancer Result :  Melanoma','2025-03-31'),
(14,5,'static/uploads/a991186a-ae66-4e46-b036-936c64576bccabc.jpg','Result :  Eczema Photos  \n No Cancer ','2025-03-31'),
(15,5,'static/uploads/63aa65d9-2dc2-40ef-8e1a-7602b019168aabc.jpg','Result :  Melanoma Skin Cancer Nevi and Moles  \nCancer Result :  Melanoma','2025-03-31'),
(16,5,'static/uploads/4a9d7d2b-de97-4e1f-a3b3-0f5e1b69f233abc.jpg','Result :  Actinic Keratosis Basal Cell Carcinoma and other Malignant Lesions  \nCancer Result :  Basal cell carc','2025-03-31'),
(17,8,'static/uploads/8067dc79-6863-48fa-b159-1b7328e58d45abc.jpg','Result :  Bullous Disease Photos  \n No Cancer ','2025-04-01'),
(18,8,'static/uploads/f72c32f6-1b0d-4e5a-8f1f-ddedefe31992abc.jpg','Result :  Invalid Image  \n No Cancer ','2025-04-01');

/*Table structure for table `rating` */

DROP TABLE IF EXISTS `rating`;

CREATE TABLE `rating` (
  `rating_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `rated` varchar(111) DEFAULT NULL,
  `feedback` varchar(111) DEFAULT NULL,
  `date` varchar(111) DEFAULT NULL,
  PRIMARY KEY (`rating_id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

/*Data for the table `rating` */

insert  into `rating`(`rating_id`,`user_id`,`rated`,`feedback`,`date`) values 
(1,1,'3','rrrrr','2024-10-15'),
(2,2,'ghhfg','3.0','2024-11-21'),
(3,3,'ss','3.0','2025-01-12'),
(4,5,'nice','5.0','2025-03-30'),
(5,8,'good','5.0','2025-04-01');

/*Table structure for table `remady` */

DROP TABLE IF EXISTS `remady`;

CREATE TABLE `remady` (
  `remady_id` int(11) NOT NULL AUTO_INCREMENT,
  `appointment_id` int(11) DEFAULT NULL,
  `remady` varchar(100) DEFAULT NULL,
  `user_id` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`remady_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

/*Data for the table `remady` */

insert  into `remady`(`remady_id`,`appointment_id`,`remady`,`user_id`) values 
(1,2,'dfrgthy','1'),
(2,14,'drink more water','5'),
(3,14,'water','5'),
(4,27,'drink water','8');

/*Table structure for table `skin` */

DROP TABLE IF EXISTS `skin`;

CREATE TABLE `skin` (
  `skin_id` int(11) NOT NULL AUTO_INCREMENT,
  `skin` varchar(1000) DEFAULT NULL,
  `details` varchar(10000) DEFAULT NULL,
  PRIMARY KEY (`skin_id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

/*Data for the table `skin` */

insert  into `skin`(`skin_id`,`skin`,`details`) values 
(4,'static/d58c69b9-e79d-4312-9f30-7fb312ba0010image 1 skin.jpg','irritation'),
(2,'static/a98b6337-fbe5-431d-8173-69e160e71165White aesthetic clean tones Lightroom presets for Products, Home, Interior photography.jpg','hey '),
(3,'static/0af7d2b8-89e2-4873-ae45-c943d3e3dd115d93f7e5-1674-4cb7-a285-b8bad3247f0f.jpg','hey bro');

/*Table structure for table `symptoms` */

DROP TABLE IF EXISTS `symptoms`;

CREATE TABLE `symptoms` (
  `symptom_id` int(11) NOT NULL AUTO_INCREMENT,
  `alzimers_id` int(11) DEFAULT NULL,
  `symptoms` varchar(111) DEFAULT NULL,
  PRIMARY KEY (`symptom_id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

/*Data for the table `symptoms` */

insert  into `symptoms`(`symptom_id`,`alzimers_id`,`symptoms`) values 
(1,3,'hui'),
(2,3,'hgy'),
(4,4,'fsdfsdf');

/*Table structure for table `users` */

DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `login_id` int(11) DEFAULT NULL,
  `firstname` varchar(111) DEFAULT NULL,
  `bloodgroup` varchar(10) DEFAULT NULL,
  `gender` varchar(20) DEFAULT NULL,
  `age` varchar(10) DEFAULT NULL,
  `phone` varchar(111) DEFAULT NULL,
  `email` varchar(111) DEFAULT NULL,
  `lati` varchar(100) DEFAULT NULL,
  `longi` varchar(200) DEFAULT NULL,
  `photo` varchar(1000) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

/*Data for the table `users` */

insert  into `users`(`user_id`,`login_id`,`firstname`,`bloodgroup`,`gender`,`age`,`phone`,`email`,`lati`,`longi`,`photo`) values 
(6,17,'arya','b+',NULL,'55','5656567899','arya@gmqil.com','9.9763084','76.2861721','static/images/8df97688-1bb7-4bf0-a31c-411848b41aa41000157739.jpg'),
(5,16,'ammu','b+',NULL,'55','5656565656','ammu@gmail.com','9.9763066','76.2862123','static/images/f5030401-7d5d-4148-879a-7ca1e9c3ff391000149368.jpg'),
(7,22,'zarah ','null','null','null','','','Ernakulam ','8569741236','zarffh@gmail.com'),
(8,23,'roy','null','null','null','','','kochi','5698745236','roy@gmail.com'),
(9,33,'Sara','null','null','null','','','kochi','8965742315','sara@gmail.com');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
